/*#ifndef NO_C_MAIN
  #ifdef IBM
  extern void drive_nekton();
  int main()
  {
    drive_nekton();
    return 0;
  }
  #else
  extern void drive_nekton_();
  int main()
  {
    drive_nekton_();
    return 0;
  }
  #endif
  #endif
*/
