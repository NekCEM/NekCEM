
void
main(void)
{
  nekton_();
}
