#!/bin/bash

# this is for MPI runs on Vesta/Cetus/Mira

for proc in 'MPI' ; do
    for nproc in 32 64 128 ; do
	for ele in 32 64 128; do
	    dir=${proc}_${nproc}_${ele}
	    #Make new directory
	    if [ "$ele" -ge "$nproc" ]; then

	    mkdir ../${dir}
	    cd ../${dir}
	    echo $proc
	    #copy in the right files
 	    if [ $proc == 'MPI' ]; then
 	    	cp ../mpi_scale/* .
 	    else
 	    	echo 'Must be MPI '
 	    	exit
 	    fi
	    
	    #Change box file
	    sed -i '/(number of elements/c\-1 -1 -'$ele' (number of elements in x,y,z)' box.box

	    #Submit job
	    if   [ $nproc == 32 ]; then
 		../../bin/nek_c32 box 1 $nproc
		echo 'hello',$proc,$nproc,$ele
	    elif [ $nproc == 64 ]; then
 		../../bin/nek_c32 box 2 $nproc
		echo 'hello',$proc,$nproc,$ele
	    elif [ $nproc == 128 ]; then
 		../../bin/nek_c32 box 4 $nproc
		echo 'hello',$proc,$nproc,$ele
	    else
		echo 'Must be MPI'
		exit
	    fi
          fi
	done
    done
done
